# Subtask AI Batch Worker (Node.js >=20)

A permission-gated, offline-capable CLI batch processor. It **does not** connect to GitHub or Subtask, publish content, or bypass company network controls. Only use on systems where commercial/personal work and transfers are explicitly authorized.

## Setup

```bash
npm install
cp config.example.json config.json
```

Windows PowerShell: `Copy-Item config.example.json config.json`.

Configure `command` and `args` to match your **approved** CLI's noninteractive mode. The example `glm --print` is a placeholder and may not exist. This implementation sends the prompt to stdin; confirm your CLI supports that. CLI must output raw JSON on stdout. Do not put secrets in config.json.

```bash
npm run enqueue
npm run run
npm run status
npm run export
```

To enqueue a different file: `node src/index.js enqueue my-tasks.jsonl`.

Outputs are in `outputs/`; inspect them before any import or publication. The export manifest includes SHA-256 digests. It is not a digital signature. No external publication is implemented.

## Limitations

- Single worker process only; do not run concurrent `run` commands.
- Retries occur within the running process; a subsequent `run` resumes pending tasks.
- If a worker crashes after writing an output but before committing DB state, the task can run again. Downstream import should be idempotent by task ID.
- SQLite file and outputs may contain sensitive task context; restrict directory access and do not commit them.
- CLI may emit startup banners or Markdown fences; only a JSON object or JSON code fence is accepted.
- The example uses one general schema for all task types. Production should add type-specific schemas, content deduplication, factual verification and manual approval.
- Task context is untrusted; generated content and code require review.
